package com.example.koffi;

public class Store {
    String id;
    String address;
    String image;
    String phoneNumber;

    public Store(String id,String address, String image, String phoneNumber) {
        this.id = id;
        this.address = address;
        this.image = image;
        this.phoneNumber = phoneNumber;
    }
}
